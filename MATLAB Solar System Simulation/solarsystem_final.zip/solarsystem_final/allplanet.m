close all; clc;
run values.m;
tic
% Create figure
figure("Position", [100 100 1280 720]);
axis equal;
xlabel('x (m)');
ylabel('y (m)');
title('Orbit of all planets around the sun');
hold on;

% Parameters
G = 6.67430e-11; % Gravitational constant (m^3 kg^-1 s^-2)
m_sun = 1.989e30; % Mass of the sun (kg)

% Time parameters
dt = 86400; % Time step (1 hour in seconds)
t_end = 248 * 365 * 24 * 3600; % End time (1 year in seconds)
t = 0:dt:t_end;

[spherex, spherey, spherez] = sphere(20);
sunx = r_sun*spherex; suny = r_sun*spherey; sunz = r_sun*spherez;

earthx = r_earth*spherex; earthy = r_earth*spherey; earthz = r_earth*spherez;

% Initial conditions
x0_earth = apogee_earth; % Initial x position
y0_earth = 0; % Initial y position
r0_earth = [x0_earth, y0_earth, 0];
v0_earth = sqrt(G*m_sun*((2/apogee_earth) - (1/semi_major_axis_earth))); % Magnitude of initial velocity
v0x_earth = 0; % Initial x velocity
v0y_earth = v0_earth; % Initial y velocity

% Initialization
x_earth = zeros(size(t));
y_earth = zeros(size(t));
z_earth = zeros(size(t));
vx_earth = zeros(size(t));
vy_earth = zeros(size(t));
vz_earth = zeros(size(t));
x_earth(1) = x0_earth;
y_earth(1) = y0_earth;
vx_earth(1) = v0x_earth;
vy_earth(1) = v0y_earth;

% Initialize plot for orbit
orbit_earth = animatedline('LineStyle', '--', 'Color','b', 'LineWidth',3);
% Animation loop
earth = surf(earthx, earthy, -earthz);
set(earth, 'CData', earth_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
% Mercury
mercuryx = r_mercury*spherex; mercuryy = r_mercury*spherey; mercuryz = r_mercury*spherez;

% Initial conditions
x0_mercury = -0.501875355265e+10; % Initial x position
y0_mercury = -5.94344691564e+10; % Initial y position
r0_mercury = [x0_mercury, y0_mercury];
%v0_mercury = sqrt(G*m_sun*((2/perigee_mercury) - (1/semi_major_axis_mercury))); % Magnitude of initial velocity
v0x_mercury = 44529.2049202; % Initial x velocity
v0y_mercury = -13317.1693666; % Initial y velocity

% Initialization
x_mercury = zeros(size(t));
y_mercury = zeros(size(t));
z_mercury = zeros(size(t));
vx_mercury = zeros(size(t));
vy_mercury = zeros(size(t));
vz_mercury = zeros(size(t));
x_mercury(1) = x0_mercury;
y_mercury(1) = y0_mercury;
vx_mercury(1) = v0x_mercury;
vy_mercury(1) = v0y_mercury;

% Initialize plot for orbit
orbit_mercury = animatedline('LineStyle', '--', 'Color',(1/255)*[128 128 128], 'LineWidth',3);
% Animation loop
mercury = surf(mercuryx, mercuryy, -mercuryz);
set(mercury, 'CData', mercury_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
%Venus
venusx = r_venus*spherex; venusy = r_venus*spherey; venusz = r_venus*spherez;

% Initial conditions
x0_venus = -1.00831664334e+11; % Initial x position
y0_venus = -3.72364213004e+10; % Initial y position
r0_venus = [x0_venus, y0_venus, 0];
%v0_venus = sqrt(G*m_sun*((2/apogee_venus) - (1/semi_major_axis_venus))); % Magnitude of initial velocity
v0x_venus = 12256.68051; % Initial x velocity
v0y_venus = -33061.5871747; % Initial y velocity

% Initialization
x_venus = zeros(size(t));
y_venus = zeros(size(t));
z_venus = zeros(size(t));
vx_venus = zeros(size(t));
vy_venus = zeros(size(t));
vz_venus = zeros(size(t));
x_venus(1) = x0_venus;
y_venus(1) = y0_venus;
vx_venus(1) = v0x_venus;
vy_venus(1) = v0y_venus;

% Initialize plot for orbit
orbit_venus = animatedline('LineStyle', '--', 'Color',(1/255)*[255 165 0], 'LineWidth',3);
% Animation loop
venus = surf(venusx, venusy, -venusz);
set(venus, 'CData', venus_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
%Mars
marsx = r_mars*spherex; marsy = r_mars*spherey; marsz = r_mars*spherez;

% Initial conditions
x0_mars = 4170724485.32003546; % Initial x position
y0_mars = 210072826239.6349; % Initial y position
r0_mars = [x0_mars, y0_mars];
%v0_mars = sqrt(G*m_sun*((2/perigee_mars) - (1/semi_major_axis_mars))); % Magnitude of initial velocity
v0x_mars = -2.61096900777e+04; % Initial x velocity
v0y_mars = 0.199801968623e+04; % Initial y velocity

% Initialization
x_mars = zeros(size(t));
y_mars = zeros(size(t));
z_mars = zeros(size(t));
vx_mars = zeros(size(t));
vy_mars = zeros(size(t));
vz_mars = zeros(size(t));
x_mars(1) = x0_mars;
y_mars(1) = y0_mars;
vx_mars(1) = v0x_mars;
vy_mars(1) = v0y_mars;

% Initialize plot for orbit
orbit_mars = animatedline('LineStyle', '--', 'Color','r', 'LineWidth',3);
% Animation loop
mars = surf(marsx, marsy, -marsz);
set(mars, 'CData', mars_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
% Jupiter
jupiterx = r_jupiter*spherex; jupitery = r_jupiter*spherey; jupiterz = r_jupiter*spherez;

% Initial conditions
x0_jupiter = -5.68206121386e+11; % Initial x position
y0_jupiter = 4.92334935074e+11; % Initial y position
r0_jupiter = [x0_jupiter, y0_jupiter];
%v0_jupiter = sqrt(G*m_sun*((2/apogee_jupiter) - (1/semi_major_axis_jupiter))); % Magnitude of initial velocity
v0x_jupiter = -8503.30255943; % Initial x velocity
v0y_jupiter = -10503.0928881; % Initial y velocity

% Initialization
x_jupiter = zeros(size(t));
y_jupiter = zeros(size(t));
z_jupiter = zeros(size(t));
vx_jupiter = zeros(size(t));
vy_jupiter = zeros(size(t));
vz_jupiter = zeros(size(t));
x_jupiter(1) = x0_jupiter;
y_jupiter(1) = y0_jupiter;
vx_jupiter(1) = v0x_jupiter;
vy_jupiter(1) = v0y_jupiter;

% Initialize plot for orbit
orbit_jupiter = animatedline('LineStyle', '--', 'Color',(1/255)*[180 165 40], 'LineWidth',3);
% Animation loop
jupiter = surf(jupiterx, jupitery, -jupiterz);
set(jupiter, 'CData', jupiter_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
% Saturn
saturnx = r_saturn*spherex; saturny = r_saturn*spherey; saturnz = r_saturn*spherez;

% Initial conditions
x0_saturn = 7.14644924986e+11; % Initial x position
y0_saturn = 1.25925363247e+12; % Initial y position
r0_saturn = [x0_saturn, y0_saturn];
%v0_saturn = sqrt(G*m_sun*((2/apogee_saturn) - (1/semi_major_axis_saturn))); % Magnitude of initial velocity
v0x_saturn = -8.52267657278e+03; % Initial x velocity
v0y_saturn = 4.25750816919e+03; % Initial y velocity

% Initialization
x_saturn = zeros(size(t));
y_saturn = zeros(size(t));
z_saturn = zeros(size(t));
vx_saturn = zeros(size(t));
vy_saturn = zeros(size(t));
vz_saturn = zeros(size(t));
x_saturn(1) = x0_saturn;
y_saturn(1) = y0_saturn;
vx_saturn(1) = v0x_saturn;
vy_saturn(1) = v0y_saturn;

% Initialize plot for orbit
orbit_saturn = animatedline('LineStyle', '--', 'Color',(1/255)*[190 165 0], 'LineWidth',3);
% Animation loop
saturn = surf(saturnx, saturny, -saturnz);
set(saturn, 'CData', saturn_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
% Uranus
uranusx = r_uranus*spherex; uranusy = r_uranus*spherey; uranusz = r_uranus*spherez;

% Initial conditions
x0_uranus = -1.377967244e+12; % Initial x position
y0_uranus = 2.5853197838e+12; % Initial y position
r0_uranus = [x0_uranus, y0_uranus];
%v0_uranus = sqrt(G*m_sun*((2/apogee_uranus) - (1/semi_major_axis_uranus))); % Magnitude of initial velocity
v0x_uranus = -5.74094752918e+03; % Initial x velocity
v0y_uranus = -3.38192214103e+03; % Initial y velocity

% Initialization
x_uranus = zeros(size(t));
y_uranus = zeros(size(t));
z_uranus = zeros(size(t));
vx_uranus = zeros(size(t));
vy_uranus = zeros(size(t));
vz_uranus = zeros(size(t));
x_uranus(1) = x0_uranus;
y_uranus(1) = y0_uranus;
vx_uranus(1) = v0x_uranus;
vy_uranus(1) = v0y_uranus;

% Initialize plot for orbit
orbit_uranus = animatedline('LineStyle', '--', 'Color',(1/255)*[172 229 238], 'LineWidth',3);
% Animation loop
uranus = surf(uranusx, uranusy, -uranusz);
set(uranus, 'CData', uranus_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
% Neptune
neptunex = r_neptune*spherex; neptuney = r_neptune*spherey; neptunez = r_neptune*spherez;

% Initial conditions
x0_neptune = 1.19129211762e+12; % Initial x position
y0_neptune = 4.31132553254e+12; % Initial y position
r0_neptune = [x0_neptune, y0_neptune];
%v0_neptune = sqrt(G*m_sun*((2/apogee_neptune) - (1/semi_major_axis_neptune))); % Magnitude of initial velocity
v0x_neptune = -5.2751823882e+03; % Initial x velocity
v0y_neptune = 1.42128428971e+03; % Initial y velocity

% Initialization
x_neptune = zeros(size(t));
y_neptune = zeros(size(t));
z_neptune = zeros(size(t));
vx_neptune = zeros(size(t));
vy_neptune = zeros(size(t));
vz_neptune = zeros(size(t));
x_neptune(1) = x0_neptune;
y_neptune(1) = y0_neptune;
vx_neptune(1) = v0x_neptune;
vy_neptune(1) = v0y_neptune;

% Initialize plot for orbit
orbit_neptune = animatedline('LineStyle', '--', 'Color',(1/255)*[0 165 255], 'LineWidth',3);
% Animation loop
neptune = surf(neptunex, neptuney, -neptunez);
set(neptune, 'CData', neptune_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
% Pluto
plutox = r_pluto*spherex; plutoy = r_pluto*spherey; plutoz = r_pluto*spherez;

% Initial conditions
x0_pluto = 4998870291761.615; % Initial x position
y0_pluto = 524151107838.5035; % Initial y position
z0_pluto = -1.492444140354005e+12;
r0_pluto = [x0_pluto, y0_pluto, z0_pluto];
%v0_pluto = sqrt(G*m_sun*((2/perigee_pluto) - (1/semi_major_axis_pluto))); % Magnitude of initial velocity
v0x_pluto = 490.822523487; % Initial x velocity
v0y_pluto = 5240.08952492; % Initial y velocity
v0z_pluto = -6.825927735966563e+02;

% Initialization
x_pluto = zeros(size(t));
y_pluto = zeros(size(t));
z_pluto = zeros(size(t));
vx_pluto = zeros(size(t));
vy_pluto = zeros(size(t));
vz_pluto = zeros(size(t));
x_pluto(1) = x0_pluto;
y_pluto(1) = y0_pluto;
z_pluto(1) = z0_pluto;
vx_pluto(1) = v0x_pluto;
vy_pluto(1) = v0y_pluto;
vz_pluto(1) = v0z_pluto;

% Initialize plot for orbit
orbit_pluto = animatedline('LineStyle', '--', 'Color',(1/255)*[221 196 175], 'LineWidth',3);
% Animation loop
pluto = surf(plutox, plutoy, -plutoz);
set(pluto, 'CData', pluto_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
sun = surf(sunx, suny, -sunz);
set(sun, 'CData', sun_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
view(3)
axis equal;
%set(gca, "XLim", [-2.5e11, 2.5e11], "YLim", [-2.5e11, 2.5e11])
set(gca, "XLim", [-7.5e12 7.5e12], "YLim", [-7.5e12, 7.5e12])

inbtn = uicontrol('Style', 'pushbutton', 'String', 'Zoom In',"FontWeight",'bold', 'Position', [20, 150, 100, 30]);
outbtn = uicontrol('Style', 'pushbutton', 'String', 'Zoom Out',"FontWeight",'bold', 'Position', [20, 50, 100, 30]);

% Setting function callback activation with the push of buttons
set(inbtn, 'Callback', @(src, event) zoomin(gca));
set(outbtn, 'Callback', @(src, event) zoomout(gca));

for j = 2:length(t)
    [vx_earth, vy_earth, vz_earth, x_earth, y_earth, z_earth,earthx,earthy,earthz,orbit_earth] = func_orbit(j,G,m_sun,dt, vx_earth, vy_earth, vz_earth, x_earth, y_earth, z_earth, earthx,earthy,earthz,orbit_earth,earth);
    [vx_mercury, vy_mercury, vz_mercury, x_mercury, y_mercury, z_mercury,mercuryx,mercuryy,mercuryz,orbit_mercury] = func_orbit(j,G,m_sun,dt, vx_mercury, vy_mercury, vz_mercury, x_mercury, y_mercury, z_mercury, mercuryx,mercuryy,mercuryz,orbit_mercury,mercury);
    [vx_venus, vy_venus, vz_venus, x_venus, y_venus, z_venus,venusx,venusy,venusz,orbit_venus] = func_orbit(j,G,m_sun,dt, vx_venus, vy_venus, vz_venus, x_venus, y_venus, z_venus, venusx,venusy,venusz,orbit_venus,venus);
    [vx_mars, vy_mars, vz_mars, x_mars, y_mars, z_mars,marsx,marsy,marsz,orbit_mars] = func_orbit(j,G,m_sun,dt, vx_mars, vy_mars, vz_mars, x_mars, y_mars, z_mars, marsx,marsy,marsz,orbit_mars,mars);
    [vx_jupiter, vy_jupiter, vz_jupiter, x_jupiter, y_jupiter, z_jupiter,jupiterx,jupitery,jupiterz,orbit_jupiter] = func_orbit(j,G,m_sun,dt, vx_jupiter, vy_jupiter, vz_jupiter, x_jupiter, y_jupiter, z_jupiter, jupiterx,jupitery,jupiterz,orbit_jupiter,jupiter);
    [vx_saturn, vy_saturn, vz_saturn, x_saturn, y_saturn, z_saturn,saturnx,saturny,saturnz,orbit_saturn] = func_orbit(j,G,m_sun,dt, vx_saturn, vy_saturn, vz_saturn, x_saturn, y_saturn, z_saturn, saturnx,saturny,saturnz,orbit_saturn,saturn);
    [vx_uranus, vy_uranus, vz_uranus, x_uranus, y_uranus, z_uranus,uranusx,uranusy,uranusz,orbit_uranus] = func_orbit(j,G,m_sun,dt, vx_uranus, vy_uranus, vz_uranus, x_uranus, y_uranus, z_uranus, uranusx,uranusy,uranusz,orbit_uranus,uranus);
    [vx_neptune, vy_neptune, vz_neptune, x_neptune, y_neptune, z_neptune,neptunex,neptuney,neptunez,orbit_neptune] = func_orbit(j,G,m_sun,dt, vx_neptune, vy_neptune, vz_neptune, x_neptune, y_neptune, z_neptune, neptunex,neptuney,neptunez,orbit_neptune,neptune);
    [vx_pluto, vy_pluto, vz_pluto, x_pluto, y_pluto, z_pluto,plutox,plutoy,plutoz,orbit_pluto] = func_orbit(j,G,m_sun,dt, vx_pluto, vy_pluto, vz_pluto, x_pluto, y_pluto, z_pluto, plutox,plutoy,plutoz,orbit_pluto,pluto);
    %pause(0.01);
    disp(t(j)/(dt))
end

%save stats.mat
% was only ran ONCE to save .mat values
toc

function [vx_planet, vy_planet, vz_planet, x_planet, y_planet, z_planet,planetx,planety,planetz,orbit_planet] = func_orbit(i,G,m_sun,dt, vx_planet, vy_planet, vz_planet, x_planet, y_planet, z_planet, planetx,planety,planetz,orbit_planet,planet)
    r_planet = [x_planet(i-1), y_planet(i-1), z_planet(i-1)]; % Position vector
    r_planet_mag = norm(r_planet); % Magnitude of position vector
    
    % Gravitational force
    a_planet = -G * m_sun/r_planet_mag^3 * r_planet;
    % Update velocity and position
    vx_planet(i) = vx_planet(i-1) + a_planet(1) * dt;
    vy_planet(i) = vy_planet(i-1) + a_planet(2) * dt;
    vz_planet(i) = vz_planet(i-1) + a_planet(3) * dt;
    x_planet(i) = x_planet(i-1) + vx_planet(i) * dt;
    y_planet(i) = y_planet(i-1) + vy_planet(i) * dt;
    z_planet(i) = z_planet(i-1) + vz_planet(i) * dt;
    %addpoints(orbit_planet, x_planet(i), y_planet(i), z_planet(i))
    %set(planet, 'XData', planetx + x_planet(i), 'YData', planety + y_planet(i), 'Zdata', planetz + z_planet(i));
end

function zoomin(gca)
set(gca, 'Xlim', 0.9*gca().XLim, 'Ylim', 0.9*gca().YLim)
end
function zoomout(gca)
set(gca, 'Xlim', 1.1*gca().XLim, 'Ylim', 1.1*gca().YLim)
end