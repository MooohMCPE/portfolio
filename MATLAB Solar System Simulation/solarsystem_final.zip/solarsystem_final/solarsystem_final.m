close all; clc
all_fig = findall(0, 'type', 'figure');
close(all_fig)
load stats.mat
run values.m

% Create figure
figure("Position", [100 100 1280 720], 'color', [0 0 0], 'Name', 'Solar System');
axis equal; axis off;
xlabel('x (m)');
ylabel('y (m)');
title('Orbit of all planets around the sun');
hold on;
% Parameters
G = 6.67430e-11;
m_sun = 1.989e30;
% Time parameters
dt = 86400;
t_end = 248 * 365 * 24 * 3600;
t = 0:dt:t_end;

% Sun

x_sun = zeros(1,length(t));
y_sun = zeros(1,length(t));
z_sun = zeros(1,length(t));

[spherex, spherey, spherez] = sphere(20);
sunx = r_sun*spherex; suny = r_sun*spherey; sunz = r_sun*spherez;

% Earth

earthx = r_earth*spherex; earthy = r_earth*spherey; earthz = r_earth*spherez;
set(gca, 'color', [0 0 0])


earth = surf(earthx, earthy, -earthz);
set(earth, 'CData', earth_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
% Mercury
mercuryx = r_mercury*spherex; mercuryy = r_mercury*spherey; mercuryz = r_mercury*spherez;


mercury = surf(mercuryx, mercuryy, -mercuryz);
set(mercury, 'CData', mercury_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
%Venus
venusx = r_venus*spherex; venusy = r_venus*spherey; venusz = r_venus*spherez;



venus = surf(venusx, venusy, -venusz);
set(venus, 'CData', venus_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
%Mars
marsx = r_mars*spherex; marsy = r_mars*spherey; marsz = r_mars*spherez;



mars = surf(marsx, marsy, -marsz);
set(mars, 'CData', mars_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
% Jupiter
jupiterx = r_jupiter*spherex; jupitery = r_jupiter*spherey; jupiterz = r_jupiter*spherez;


jupiter = surf(jupiterx, jupitery, -jupiterz);
set(jupiter, 'CData', jupiter_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
% Saturn
saturnx = r_saturn*spherex; saturny = r_saturn*spherey; saturnz = r_saturn*spherez;



saturn = surf(saturnx, saturny, -saturnz);
set(saturn, 'CData', saturn_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');

theta = 0:0.01:2*pi;
xring = 2*r_saturn*cos(theta);
yring = 2*r_saturn*sin(theta);
zero = zeros(1, length(xring));
xring = [xring; 0.7*xring];
yring = [yring; 0.7*yring];
zero = [zero; zero];
saturn_ring = surf(xring, yring, zero, 'FaceColor','texturemap','CData',ring_img, 'EdgeColor','none');

% Uranus
uranusx = r_uranus*spherex; uranusy = r_uranus*spherey; uranusz = r_uranus*spherez;



uranus = surf(uranusx, uranusy, -uranusz);
set(uranus, 'CData', uranus_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
% Neptune
neptunex = r_neptune*spherex; neptuney = r_neptune*spherey; neptunez = r_neptune*spherez;



neptune = surf(neptunex, neptuney, -neptunez);
set(neptune, 'CData', neptune_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
% Pluto
plutox = r_pluto*spherex; plutoy = r_pluto*spherey; plutoz = r_pluto*spherez;


pluto = surf(plutox, plutoy, -plutoz);
set(pluto, 'CData', pluto_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
sun = surf(sunx, suny, -sunz);
set(sun, 'CData', sun_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
view(3)
axis equal;
set(gca, "XLim", [-7.5e12 7.5e12], "YLim", [-7.5e12, 7.5e12], 'CameraTarget', [0 0 0])

inbtn = uicontrol('Style', 'pushbutton', 'String', 'Zoom In',"FontWeight",'bold', 'Position', [20, 650, 100, 30]);
outbtn = uicontrol('Style', 'pushbutton', 'String', 'Zoom Out',"FontWeight",'bold', 'Position', [20, 600, 100, 30]);
sunbtn = uicontrol('Style', 'pushbutton', 'String', 'Sun',"FontWeight",'bold', 'Position', [20, 500, 100, 30]);
mercbtn = uicontrol('Style', 'pushbutton', 'String', 'Mercury',"FontWeight",'bold', 'Position', [20, 450, 100, 30]);
venusbtn = uicontrol('Style', 'pushbutton', 'String', 'Venus',"FontWeight",'bold', 'Position', [20, 400, 100, 30]);
earthbtn = uicontrol('Style', 'pushbutton', 'String', 'Earth',"FontWeight",'bold', 'Position', [20, 350, 100, 30]);
marsbtn = uicontrol('Style', 'pushbutton', 'String', 'Mars',"FontWeight",'bold', 'Position', [20, 300, 100, 30]);
jupiterbtn = uicontrol('Style', 'pushbutton', 'String', 'Jupiter',"FontWeight",'bold', 'Position', [20, 250, 100, 30]);
saturnbtn = uicontrol('Style', 'pushbutton', 'String', 'Saturn',"FontWeight",'bold', 'Position', [20, 200, 100, 30]);
uranusbtn = uicontrol('Style', 'pushbutton', 'String', 'Uranus',"FontWeight",'bold', 'Position', [20, 150, 100, 30]);
neptunebtn = uicontrol('Style', 'pushbutton', 'String', 'Neptune',"FontWeight",'bold', 'Position', [20, 100, 100, 30]);
plutobtn = uicontrol('Style', 'pushbutton', 'String', 'Pluto',"FontWeight",'bold', 'Position', [20, 50, 100, 30]);

% defining cam as an object with class object

cam = val_object(x_sun, y_sun, z_sun);

% setting function callback activation with the push of buttons

set(inbtn, 'Callback', @(src, event) zoom(0.5));
set(outbtn, 'Callback', @(src, event) zoom(-0.5));

set(sunbtn, 'Callback', @(src, event) set_focus(x_sun, y_sun, z_sun, cam));
set(mercbtn, 'Callback', @(src, event) set_focus(x_mercury, y_mercury, z_mercury, cam));
set(venusbtn, 'Callback', @(src, event) set_focus(x_venus, y_venus, z_venus, cam));
set(earthbtn, 'Callback', @(src, event) set_focus(x_earth, y_earth, z_earth, cam));
set(marsbtn, 'Callback', @(src, event) set_focus(x_mars, y_mars, z_mars, cam));
set(jupiterbtn, 'Callback', @(src, event) set_focus(x_jupiter, y_jupiter, z_jupiter, cam));
set(saturnbtn, 'Callback', @(src, event) set_focus(x_saturn, y_saturn, z_saturn, cam));
set(uranusbtn, 'Callback', @(src, event) set_focus(x_uranus, y_uranus, z_uranus, cam));
set(neptunebtn, 'Callback', @(src, event) set_focus(x_neptune, y_neptune, z_neptune, cam));
set(plutobtn, 'Callback', @(src, event) set_focus(x_pluto, y_pluto, z_pluto, cam));

% plot the preexisting orbits of planets

plot3(x_earth(1:366), y_earth(1:366), z_earth(1:366),'Color', 'b')
plot3(x_mercury(1:89), y_mercury(1:89), z_mercury(1:89), 'Color',(1/255)*[128 128 128])
plot3(x_venus(1:226), y_venus(1:226), z_venus(1:226), 'Color',(1/255)*[255 165 0])
plot3(x_mars(1:700), y_mars(1:700), z_mars(1:700), 'Color','r')
plot3(x_jupiter(1:4334), y_jupiter(1:4334), z_jupiter(1:4334), 'Color',(1/255)*[157 118 79])
plot3(x_saturn(1:11060), y_saturn(1:11060), z_saturn(1:11060), 'Color',(1/255)*[193 174 134])
plot3(x_uranus(1:30988), y_uranus(1:30988), z_uranus(1:30988), 'Color',(1/255)*[172 229 238])
plot3(x_neptune(1:60291), y_neptune(1:60291), z_neptune(1:60291), 'Color',(1/255)*[0 165 255])
plot3([x_pluto x_pluto(1)], [y_pluto y_pluto(1)], [z_pluto z_pluto(1)], 'Color',(1/255)*[221 196 175])

% constant animation loop

for i = 1:length(t)
    x_focus = cam.x; y_focus = cam.y; z_focus = cam.z;
    drawer(i, x_mercury, y_mercury, z_mercury, mercury, mercuryx, mercuryy, mercuryz,x_venus, y_venus, z_venus, venus, venusx, venusy, venusz,x_earth, y_earth, z_earth, earth, earthx, earthy, earthz,x_mars, y_mars, z_mars, mars, marsx, marsy, marsz,x_jupiter, y_jupiter, z_jupiter, jupiter, jupiterx, jupitery, jupiterz,x_saturn, y_saturn, z_saturn, saturn, saturnx, saturny, saturnz,x_uranus, y_uranus, z_uranus, uranus, uranusx, uranusy, uranusz,x_neptune, y_neptune, z_neptune, neptune, neptunex, neptuney, neptunez,x_pluto, y_pluto, z_pluto, pluto, plutox, plutoy, plutoz)
    set(saturn_ring, 'Xdata', xring + x_saturn(i), 'YData', yring + y_saturn(i))
    focus([x_focus(i), y_focus(i), z_focus(i)])
    pause(0.1)
end


% function to draw all planets
function drawer(i, x_mercury, y_mercury, z_mercury, mercury, mercuryx, mercuryy, mercuryz,x_venus, y_venus, z_venus, venus, venusx, venusy, venusz,x_earth, y_earth, z_earth, earth, earthx, earthy, earthz,x_mars, y_mars, z_mars, mars, marsx, marsy, marsz,x_jupiter, y_jupiter, z_jupiter, jupiter, jupiterx, jupitery, jupiterz,x_saturn, y_saturn, z_saturn, saturn, saturnx, saturny, saturnz,x_uranus, y_uranus, z_uranus, uranus, uranusx, uranusy, uranusz,x_neptune, y_neptune, z_neptune, neptune, neptunex, neptuney, neptunez,x_pluto, y_pluto, z_pluto, pluto, plutox, plutoy, plutoz)
draw(x_earth, y_earth, z_earth, earth, earthx, earthy, earthz, i);
draw(x_mercury, y_mercury, z_mercury, mercury, mercuryx, mercuryy, mercuryz, i);
draw(x_venus, y_venus, z_venus, venus, venusx, venusy, venusz, i);
draw(x_mars, y_mars, z_mars, mars, marsx, marsy, marsz, i);
draw(x_jupiter, y_jupiter, z_jupiter, jupiter, jupiterx, jupitery, jupiterz, i);
draw(x_saturn, y_saturn, z_saturn, saturn, saturnx, saturny, saturnz, i);
draw(x_uranus, y_uranus, z_uranus, uranus, uranusx, uranusy, uranusz, i);
draw(x_neptune, y_neptune, z_neptune, neptune, neptunex, neptuney, neptunez, i);
draw(x_pluto, y_pluto, z_pluto, pluto, plutox, plutoy, plutoz, i);
end

% function to draw individual planet

function draw(x_planet, y_planet, z_planet, planet, planetx, planety, planetz, j)
set(planet, 'XData', planetx + x_planet(j), 'YData', planety + y_planet(j), 'ZData', planetz + z_planet(j));
end

% zoom function for camera

function zoom(dist) %dist in the range [-1 1]
set(gca,'CameraViewAngleMode','manual')
newcp = cpos - dist * (cpos - ctarg);
set(gca,'CameraPosition',newcp)
end

% functions to quickly obtain camera position and target

function out = cpos
out = get(gca,'CameraPosition');
end
function out = ctarg
out = get(gca,'CameraTarget');
end

% function to set camera target on position

function focus(pos)
set(gca, 'CameraTarget', pos)
end

% setter function to define which planet we must follow

function set_focus(x_f, y_f, z_f, cam)
    cam.x = x_f;
    cam.y = y_f;
    cam.z = z_f;
end
