close all; clc;
run values.m;
tic;
% Create figure
figure("Position", [100 100 1280 720]);
axis equal;
xlabel('x (m)');
ylabel('y (m)');
title('Orbit of planets mercury to mars around the sun');
hold on;
% Parameters
G = 6.67430e-11; % Gravitational constant (m^3 kg^-1 s^-2)
m_sun = 1.989e30; % Mass of the sun (kg)

% Time parameters
dt = 86400; % Time step (1 hour in seconds)
t_end = 730 * 24 * 3600; % End time (1 year in seconds)
t = 0:dt:t_end;

[spherex, spherey, spherez] = sphere(20);
sunx = r_sun*spherex; suny = r_sun*spherey; sunz = r_sun*spherez;

earthx = r_earth*spherex; earthy = r_earth*spherey; earthz = r_earth*spherez;

% Initial conditions
x0_earth = apogee_earth; % Initial x position
y0_earth = 0; % Initial y position
r0_earth = [x0_earth, y0_earth];
v0_earth = sqrt(G*m_sun*((2/apogee_earth) - (1/semi_major_axis_earth))); % Magnitude of initial velocity
v0x_earth = 0; % Initial x velocity
v0y_earth = v0_earth; % Initial y velocity

% Initialization
x_earth = zeros(size(t));
y_earth = zeros(size(t));
vx_earth = zeros(size(t));
vy_earth = zeros(size(t));
x_earth(1) = x0_earth;
y_earth(1) = y0_earth;
vx_earth(1) = v0x_earth;
vy_earth(1) = v0y_earth;

% Initialize plot for orbit
orbit_earth = animatedline('LineStyle', '--', 'Color','b');
% Animation loop
earth = surf(earthx, earthy, -earthz);
set(earth, 'CData', earth_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
% Mercury
mercuryx = r_mercury*spherex; mercuryy = r_mercury*spherey; mercuryz = r_mercury*spherez;

% Initial conditions
x0_mercury = -0.501875355265e+10; % Initial x position
y0_mercury = -5.94344691564e+10; % Initial y position
r0_mercury = [x0_mercury, y0_mercury];
%v0_mercury = sqrt(G*m_sun*((2/perigee_mercury) - (1/semi_major_axis_mercury))); % Magnitude of initial velocity
v0x_mercury = 44529.2049202; % Initial x velocity
v0y_mercury = -13317.1693666; % Initial y velocity

% Initialization
x_mercury = zeros(size(t));
y_mercury = zeros(size(t));
vx_mercury = zeros(size(t));
vy_mercury = zeros(size(t));
x_mercury(1) = x0_mercury;
y_mercury(1) = y0_mercury;
vx_mercury(1) = v0x_mercury;
vy_mercury(1) = v0y_mercury;

% Initialize plot for orbit
orbit_mercury = animatedline('LineStyle', '--', 'Color',(1/255)*[128 128 128]);
% Animation loop
mercury = surf(mercuryx, mercuryy, -mercuryz);
set(mercury, 'CData', mercury_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
%Venus
venusx = r_venus*spherex; venusy = r_venus*spherey; venusz = r_venus*spherez;

% Initial conditions
x0_venus = -1.00831664334e+11; % Initial x position
y0_venus = -3.72364213004e+10; % Initial y position
r0_venus = [x0_venus, y0_venus];
%v0_venus = sqrt(G*m_sun*((2/apogee_venus) - (1/semi_major_axis_venus))); % Magnitude of initial velocity
v0x_venus = 12256.68051; % Initial x velocity
v0y_venus = -33061.5871747; % Initial y velocity

% Initialization
x_venus = zeros(size(t));
y_venus = zeros(size(t));
vx_venus = zeros(size(t));
vy_venus = zeros(size(t));
x_venus(1) = x0_venus;
y_venus(1) = y0_venus;
vx_venus(1) = v0x_venus;
vy_venus(1) = v0y_venus;

% Initialize plot for orbit
orbit_venus = animatedline('LineStyle', '--', 'Color',(1/255)*[255 165 0]);
% Animation loop
venus = surf(venusx, venusy, -venusz);
set(venus, 'CData', venus_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
%Mars
marsx = r_mars*spherex; marsy = r_mars*spherey; marsz = r_mars*spherez;

% Initial conditions
x0_mars = 4170724485.32003546; % Initial x position
y0_mars = 210072826239.6349; % Initial y position
r0_mars = [x0_mars, y0_mars];
%v0_mars = sqrt(G*m_sun*((2/perigee_mars) - (1/semi_major_axis_mars))); % Magnitude of initial velocity
v0x_mars = -2.61096900777e+04; % Initial x velocity
v0y_mars = 0.199801968623e+04; % Initial y velocity

% Initialization
x_mars = zeros(size(t));
y_mars = zeros(size(t));
vx_mars = zeros(size(t));
vy_mars = zeros(size(t));
x_mars(1) = x0_mars;
y_mars(1) = y0_mars;
vx_mars(1) = v0x_mars;
vy_mars(1) = v0y_mars;

% Initialize plot for orbit
orbit_mars = animatedline('LineStyle', '--', 'Color','r');
% Animation loop
mars = surf(marsx, marsy, -marsz);
set(mars, 'CData', mars_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');

sun = surf(sunx, suny, -sunz);
set(sun, 'CData', sun_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
view(3)
set(gca, 'Xlim', [-2.5e11 2.5e11], 'Ylim', [-2.5e11 2.5e11])


for j = 2:length(t)
    [vx_earth, vy_earth, x_earth, y_earth,earthx,earthy,orbit_earth,earth] = func_orbit(j,G,m_sun,t,dt, vx_earth, vy_earth, x_earth, y_earth,earthx,earthy,orbit_earth,earth);
    [vx_mercury, vy_mercury, x_mercury, y_mercury,mercuryx,mercuryy,orbit_mercury,mercury] = func_orbit(j,G,m_sun,t,dt, vx_mercury, vy_mercury, x_mercury, y_mercury,mercuryx,mercuryy,orbit_mercury,mercury);
    [vx_venus, vy_venus, x_venus, y_venus,venusx,venusy,orbit_venus,venus] = func_orbit(j,G,m_sun,t,dt, vx_venus, vy_venus, x_venus, y_venus,venusx,venusy,orbit_venus,venus);
    [vx_mars, vy_mars, x_mars, y_mars,marsx,marsy,orbit_mars,mars] = func_orbit(j,G,m_sun,t,dt, vx_mars, vy_mars, x_mars, y_mars,marsx,marsy,orbit_mars,mars);
    pause(0.01)    
end
toc;
function [vx_planet, vy_planet, x_planet, y_planet,planetx,planety,orbit_planet,planet] = func_orbit(i,G,m_sun,t,dt, vx_planet, vy_planet, x_planet, y_planet,planetx,planety,orbit_planet,planet)
    r_planet = [x_planet(i-1), y_planet(i-1)]; % Position vector
    r_planet_mag = norm(r_planet); % Magnitude of position vector
    
    % Gravitational force
    a_planet = -G * m_sun/r_planet_mag^3 * r_planet;
    % Update velocity and position
    vx_planet(i) = vx_planet(i-1) + a_planet(1) * dt;
    vy_planet(i) = vy_planet(i-1) + a_planet(2) * dt;
    x_planet(i) = x_planet(i-1) + vx_planet(i) * dt;
    y_planet(i) = y_planet(i-1) + vy_planet(i) * dt;
    addpoints(orbit_planet, x_planet(i), y_planet(i))
    set(planet, 'XData', planetx+x_planet(i), 'YData', planety+y_planet(i));
    %drawnow;
    disp(t(i)/dt)
end
