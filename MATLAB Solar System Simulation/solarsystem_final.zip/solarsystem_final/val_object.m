    classdef val_object < handle
        properties
            x
            y
            z
        end
        
        methods
            % Constructor
            function obj = val_object(x, y, z)
                if nargin == 3
                    obj.x = x;
                    obj.y = y;
                    obj.z = z;
                else
                    % Default constructor
                    obj.x = [];
                    obj.y = [];
                    obj.z = [];
                end
            end
            
            % Setter methods
            function setX(obj, newX)
                validateattributes(newX, {'numeric'}, {'vector'});
                obj.x = newX;
            end
            
            function setY(obj, newY)
                validateattributes(newY, {'numeric'}, {'vector'});
                obj.y = newY;
            end
            
            function setZ(obj, newZ)
                validateattributes(newZ, {'numeric'}, {'vector'});
                obj.z = newZ;
            end
        end
    end
