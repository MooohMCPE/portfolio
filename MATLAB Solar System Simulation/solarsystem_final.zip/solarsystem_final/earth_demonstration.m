close all; clc;
run values.m;

% Create figure
figure("Position", [100 100 1280 720]);
axis equal;
xlabel('x (m)');
ylabel('y (m)');
title('Orbit of the earth around the sun');
hold on;

% Parameters
G = 6.67430e-11; % Gravitational constant
m_sun = 1.989e30; % Mass of the sun
[spherex, spherey, spherez] = sphere(20);
sunx = r_sun*spherex; suny = r_sun*spherey; sunz = r_sun*spherez;
earthx = r_earth*spherex; earthy = r_earth*spherey; earthz = r_earth*spherez;

% Initial conditions
x0_earth = apogee_earth; % Initial x position
y0_earth = 0; % Initial y position
r0_earth = [x0_earth, y0_earth];
v0_earth = sqrt((G*m_sun/(semi_major_axis_earth))*(semi_major_axis_earth-c_earth)/(semi_major_axis_earth+c_earth)); % Magnitude of initial velocity
v0x_earth = 0; % Initial x velocity
v0y_earth = v0_earth; % Initial y velocity

% Time parameters
dt = 86400; % Time step (1 hour in seconds)
t_end = 730*24*3600; % End time (2 year in seconds)

% Initialization
t = 0:dt:t_end;
x_earth = zeros(size(t));
y_earth = zeros(size(t));
vx_earth = zeros(size(t));
vy_earth = zeros(size(t));
x_earth(1) = x0_earth;
y_earth(1) = y0_earth;
vx_earth(1) = v0x_earth;
vy_earth(1) = v0y_earth;

% Initialize plot for orbit
orbit_earth = animatedline('LineStyle', '--', 'Color','b');
% Animation loop
earth = surf(earthx, earthy, -earthz);
sun = surf(sunx, suny, -sunz);
set(earth, 'CData', earth_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
set(sun, 'CData', sun_pic, 'FaceColor', 'texturemap', 'EdgeColor', 'none');
view(3)
set(gca, 'Xlim', [-2.5e11 2.5e11], 'Ylim', [-2.5e11 2.5e11])

for i = 2:length(t)
    [vx_earth, vy_earth, x_earth, y_earth,earthx,earthy,orbit_earth,earth] = func_orbit(i,G,m_sun,t,dt, vx_earth, vy_earth, x_earth, y_earth,earthx,earthy,orbit_earth,earth);
end
for i = 1:length(t)
    draw(x_earth(i), y_earth(i), orbit_earth, earth, earthx, earthy)
    pause(0.01);
    disp(i)
end

function [vx_planet, vy_planet, x_planet, y_planet,planetx,planety,orbit_planet,planet] = func_orbit(i,G,m_sun,t,dt, vx_planet, vy_planet, x_planet, y_planet,planetx,planety,orbit_planet,planet)
    r_planet = [x_planet(i-1), y_planet(i-1)]; % Position vector
    r_planet_mag = norm(r_planet); % Magnitude of position vector
    
    % Gravitational force
    a_planet = -G * m_sun/r_planet_mag^3 * r_planet;
    % Update velocity and position
    vx_planet(i) = vx_planet(i-1) + a_planet(1) * dt;
    vy_planet(i) = vy_planet(i-1) + a_planet(2) * dt;
    x_planet(i) = x_planet(i-1) + vx_planet(i) * dt;
    y_planet(i) = y_planet(i-1) + vy_planet(i) * dt;
end


function draw(x_planet, y_planet, orbit_planet, planet, planetx, planety)
    addpoints(orbit_planet, x_planet, y_planet)
    set(planet, 'XData', planetx + x_planet, 'YData', planety + y_planet);
end