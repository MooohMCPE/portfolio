close all; clc
% Parameters
G = 6.67430e-11; % Gravitational constant (m^3 kg^-1 s^-2)
m_sun = 1.989e30; % Mass of the sun (kg)
m_earth = 5.972e24; % Mass of the Earth (kg)
eccentricity = 0.0167;
semi_major_axis = 149597887.5e3; % Semi-major axis of Earth's orbit (m)
c = semi_major_axis*eccentricity;
apogee = semi_major_axis + c; perigee = semi_major_axis - c;

[earthx, earthy, earthz] = sphere(20);

% Initial conditions
x0 = apogee; % Initial x position
y0 = 0; % Initial y position
r0 = [x0, y0];
L = 2.7e40;
ve = sqrt(2*G*m_sun/apogee);
v0 = ve/sqrt(2)-10000;
%v0 = sqrt(G*m_sun*((2/apogee) - (1/semi_major_axis))); % Magnitude of initial velocity
v0x = 0; % Initial x velocity
v0y = v0; % Initial y velocity

% Time parameters
dt = 86400; % Time step (1 hour in seconds)
t_end = 730 * 24 * 3600; % End time (1 year in seconds)

% Initialization
t = 0:dt:t_end;
x = zeros(size(t));
y = zeros(size(t));
vx = zeros(size(t));
vy = zeros(size(t));
x(1) = x0;
y(1) = y0;
vx(1) = v0x;
vy(1) = v0y;

% Create figure
figure("Position", [100 100 1280 720]);
axis equal;
xlabel('x (m)');
ylabel('y (m)');
title('Orbit of the planet around the sun');
hold on;

% Plot the sun
plot(0, 0, 'ro', 'MarkerSize', 20);

% Initialize plot for orbit
orbit = animatedline('LineStyle', '--');
set(gca, 'Xlim', [-2.5e11 2.5e11], 'Ylim', [-2.5e11 2.5e11])
earth = scatter(x0, y0,'blue');
% Animation loop
for i = 2:length(t)
    r = [x(i-1), y(i-1)]; % Position vector
    r_mag = norm(r); % Magnitude of position vector
    
    % Gravitational force
    F_gravity = -G * m_sun * m_earth / r_mag^3 * r;
    a = F_gravity/m_earth;
    % Update velocity and position
    vx(i) = vx(i-1) + a(1) * dt;
    vy(i) = vy(i-1) + a(2) * dt;
    x(i) = x(i-1) + vx(i) * dt;
    y(i) = y(i-1) + vy(i) * dt;
    
    % Update plot
    %set(orbit, 'XData', x(1:i), 'YData', y(1:i));
    addpoints(orbit, x(i), y(i))
    set(earth, 'XData', x(i), 'YData', y(i));
    disp(t(i)/dt)
    pause(0.01)
end
