e_mercury = 0.2056;
e_venus = 0.0068;
e_earth = 0.0167;
e_mars = 0.0934;
e_jupiter = 0.0484;
e_saturn = 0.0541;
e_uranus = 0.0472;
e_neptune = 0.0086;
e_pluto = 0.2488;

semi_major_axis_mercury = 57909036552;
semi_major_axis_venus = 108210500000;
semi_major_axis_earth = 149597887500;
semi_major_axis_mars = 227942250000;
semi_major_axis_jupiter = 778549300000;
semi_major_axis_saturn = 1433521450000;
semi_major_axis_uranus = 2870975810000;
semi_major_axis_neptune = 4498406710000;
semi_major_axis_pluto = 5906348325000;

c_mercury = semi_major_axis_mercury*e_mercury;
c_venus = semi_major_axis_venus*e_venus;
c_earth = semi_major_axis_earth*e_earth;
c_mars = semi_major_axis_mars*e_mars;
c_jupiter = semi_major_axis_jupiter*e_jupiter;
c_saturn = semi_major_axis_saturn*e_saturn;
c_uranus = semi_major_axis_uranus*e_uranus;
c_neptune = semi_major_axis_neptune*e_neptune;
c_pluto = semi_major_axis_pluto*e_pluto;


apogee_mercury = semi_major_axis_mercury + c_mercury;
apogee_venus = semi_major_axis_venus + c_venus;
apogee_earth = semi_major_axis_earth + c_earth;
apogee_mars = semi_major_axis_mars + c_mars;
apogee_jupiter = semi_major_axis_jupiter + c_jupiter;
apogee_saturn = semi_major_axis_saturn + c_saturn;
apogee_uranus = semi_major_axis_uranus + c_uranus;
apogee_neptune = semi_major_axis_neptune + c_neptune;
apogee_pluto = semi_major_axis_pluto + c_pluto;


perigee_mercury = semi_major_axis_mercury - c_mercury;
perigee_venus = semi_major_axis_venus - c_venus;
perigee_earth = semi_major_axis_earth - c_earth;
perigee_mars = semi_major_axis_mars - c_mars;
perigee_jupiter = semi_major_axis_jupiter - c_jupiter;
perigee_saturn = semi_major_axis_saturn - c_saturn;
perigee_uranus = semi_major_axis_uranus - c_uranus;
perigee_neptune = semi_major_axis_neptune - c_neptune;
perigee_pluto = semi_major_axis_pluto - c_pluto;

r_sun = 6.957e8 * (5e1);
r_mercury = 2.440e6 * (1e3);
r_venus = 6.052e6 * (1e3);
r_earth = 6.371e6 * (1e3);
r_mars = 3.390e6* (1e3);
r_jupiter = 6.9911e7 * (1e3);
r_saturn = 5.8232e7 * (1e3);
r_uranus = 2.5362e7 * (1e3); 
r_neptune = 2.4622e7 * (1e3);
r_pluto = 1.151e6 * (1e4);


mercury_pic = imread('mercury.jpg');
venus_pic = imread('venus.jpg');
earth_pic = imread('earth.jpg');
sun_pic = imread('sun.jpg');
mars_pic = imread('mars.jpg');
jupiter_pic = imread('jupiter.jpg');
saturn_pic = imread('saturn.jpg');
uranus_pic = imread('uranus.jpg');
neptune_pic = imread('neptune.jpg');
pluto_pic = imread('pluto.jpg');
ring_img = imread('rings.jpg');
%save values.mat








